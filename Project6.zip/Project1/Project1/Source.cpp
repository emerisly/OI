#include <bits/stdc++.h>
using namespace std;

//#define LOG ;
int arr[401];
int cow[401][401];
int range[401][401];
int maa[401][401];
int N, K;
int sort(int x, int y) {
	int ma = maa[x][y];
	int cnt = 0, sum = 0;
	for (int i = x; i <= y; i++) {
		cnt = arr[i];
		sum += ma - cnt;
	}
	return sum;
}

int go(int r, int l) {

#ifdef LOG
	printf("memo[%d][%d]is%d\n", rhs, L, memo[rhs][L]);
#endif

	int ans = 999999999;
	if (r <= K - l) { return 0; }
	if (cow[r][l] != -1) { return cow[r][l]; }
	if (l == K) { return range[0][r]; }
	int track = 0;
	for (int i = 0; i < r; i++) {
		int temp = go(i, l + 1) + range[i + 1][r];
		if (ans > temp) {
			ans = temp;
			track = i;
		}

	}
	cow[r][l] = ans;
	return ans;
}
int main() {
	//ifstream cin("/Users/kevenzhao/Desktop/USACO/sampledata/Snake.in");
	ifstream cin("snakes.in");
	ofstream fout("snakes.out");
	cin >> N >> K;
	memset(cow, -1, sizeof cow);
	for (int i = 0; i < N; i++) {
		cin >> arr[i];
	}
	for (int i = 0; i < N; i++) {
		int m = 0;
		for (int j = i; j < N; j++) {
			m = max(m, arr[j]);
			maa[i][j] = m;
		}
	}
	for (int i = 0; i < 401; i++) {
		for (int j = i; j < 401; j++) {
			range[i][j] = sort(i, j);
		}
	}
	fout << go(N - 1, 0) << endl;
}