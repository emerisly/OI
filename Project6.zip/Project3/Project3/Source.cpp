#include <iostream>
#include <sstream>
#include <string>
#include <math.h>
#include <fstream>

using namespace std;


int a, b;
int arr[99];

int main() {

	ifstream fin("/Users/Emerald Liu/Documents/cpp/ACSL/slidingPuzzleIn.txt");
	ofstream fout("/Users/Emerald Liu/Documents/cpp/ACSL/slidingPuzzleOut.txt");
	int cnt=0;
	fin>>a>>b;
	string f;
	while(fin>>f&&f!="\n"){
		stringstream num(f);
		num>>arr[cnt];
		cnt++;
	}
	int puzzle[a][a];
	int n=1;
	for(int i=0;i<a;i++){
		for(int j=0;j<a;j++){
			puzzle[i][j]=n;
			if(n==b){
				puzzle[i][j]=0;
			}
			n++;
		}
	}

	cout << 1;

	return 0;
}
