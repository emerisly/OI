//#include "iostream"

void func() { std::nullptr_t emerald; }

int main() {
	func();
}