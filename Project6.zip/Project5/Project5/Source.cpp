#include<iostream>
using namespace std;
int main() {

	system("pause");
	return 0;
}